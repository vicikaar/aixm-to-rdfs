package main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;

public class Main {

	public static void main(String[] args) {		
		try {
			Model model = RDFDataMgr.loadModel("RDF-Rules.xml");
			OutputStream streamOut = new FileOutputStream("RDF-Rules.ttl");
			RDFDataMgr.write(streamOut, model, RDFFormat.TTL);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
	}
}